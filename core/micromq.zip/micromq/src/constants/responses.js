module.exports.TIMED_OUT = JSON.stringify({
  error: 'Timed out',
});
